%% 
% Evaluate the gravity matrix G given q
function G = eval_G(q)


end