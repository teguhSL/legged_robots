%%
% Evaluate the Coriolis matrix C, given q, dq
function C = eval_C(q, dq)


end