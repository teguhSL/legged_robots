%%
% Evaluate the Mass matrix given q
function M = eval_M(q)


end