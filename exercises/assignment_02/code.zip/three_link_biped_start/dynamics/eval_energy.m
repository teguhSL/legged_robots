function [T, V] = eval_energy(q, dq)


end